# Retrofit_RxJava_MVP
Network uses Retrofit and RxJava With MVP architecture

Recent rxjava very fire, and then try to combine rxjava and Retrofit wrote a Demo, and try the next mvp

![](https://github.com/blackCave/Retrofit_RxJava_MVP/blob/master/image/C.gif)

Thanks tngou api interface [http://www.tngou.net/doc/gallery](http://www.tngou.net/doc/gallery)

#Description Framework
 	compile 'com.android.support:design:23.3.0'
    compile 'com.android.support:recyclerview-v7:23.3.0'
    compile 'com.android.support:cardview-v7:23.3.0'
    compile 'io.reactivex:rxjava:1.1.5'
    compile 'io.reactivex:rxandroid:1.2.0'
    compile 'com.squareup.retrofit2:retrofit:2.0.2'
    compile 'com.squareup.retrofit2:converter-gson:2.0.2'
    compile 'com.squareup.retrofit2:adapter-rxjava:2.0.2'
    compile 'com.github.bumptech.glide:glide:3.7.0'
    compile 'com.rengwuxian.materialedittext:library:2.1.4'
    compile 'com.jakewharton:butterknife:7.0.1'
    compile 'com.jakewharton.rxbinding:rxbinding:0.4.0'
    compile 'com.github.liuguangqiang.swipeback:library:1.0.2'
    compile 'org.greenrobot:greendao:2.2.0'
    compile 'de.hdodenhof:circleimageview:2.0.0'